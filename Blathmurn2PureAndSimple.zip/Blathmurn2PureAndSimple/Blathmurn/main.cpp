#include <iostream>
#include <windows.h>
#include <cmath>

using namespace std;

void drawPixel(HDC deviceContext, int x, int y, COLORREF color) {
	SetPixel(deviceContext, x, y, color);
}

int main() {
	HWND	consoleHandle = GetConsoleWindow();
	HDC		deviceContext = GetDC(consoleHandle);

	char* filename = "Painting.bmp";
	FILE* f = fopen(filename, "rb");
	unsigned char info[54];
	fread(info, sizeof(unsigned char), 54, f);
	int _width = *(int*)&info[18];
	int _height = *(int*)&info[22];
	int row_padded = (_width * 3 + 3) & (~3);
	unsigned char* data = new unsigned char[row_padded];
	unsigned char tmp;
	for (int i = 0; i < _height; i++){
		fread(data, sizeof(unsigned char), row_padded, f);
		for (int j = 0; j < _width * 3; j += 3) {
				tmp = data[j];
				data[j] = data[j + 2];
				data[j + 2] = tmp;
				drawPixel(deviceContext, j + 10, i + 10, RGB((int)data[j], (int)data[j + 1], (int)data[j + 2]));
			}
		}
		fclose(f);
	std::cin.ignore();
	return 0;
}